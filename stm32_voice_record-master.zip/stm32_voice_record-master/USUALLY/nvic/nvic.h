#ifndef __NVIC_H
#define	__NVIC_H


#include "stm32f10x.h"


void nvic_cfg(void);

#endif

